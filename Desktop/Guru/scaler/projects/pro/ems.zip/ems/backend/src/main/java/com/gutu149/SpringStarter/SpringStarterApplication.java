package com.gutu149.SpringStarter;

import com.gutu149.SpringStarter.model.Employee;
import com.gutu149.SpringStarter.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStarterApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringStarterApplication.class, args);
	}

	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public void run(String... args) throws Exception {
		// Assuming the Employee class has a constructor with seven parameters:
		//employeeRepository.save(new Employee(100, "Meghan", "IT", "Megha@gmail", "9989163715", 999999.0, 1));
	}
}
