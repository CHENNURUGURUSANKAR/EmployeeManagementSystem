package com.gutu149.SpringStarter.controller;

import com.gutu149.SpringStarter.exception.ResourceNotFound;
import com.gutu149.SpringStarter.model.Employee;
import com.gutu149.SpringStarter.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {
    @Autowired
    EmployeeRepository employeeRepository;

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @PostMapping
    public Employee createNewEmployee(@RequestBody Employee employee) {
        return employeeRepository.save(employee);
    }

    @GetMapping("{id}")
    public ResponseEntity<Employee> getEmployeeWithId(@PathVariable int id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFound("Employee not found with id :" + id));
        return ResponseEntity.ok(employee);
    }

    @PutMapping("{id}")
    public ResponseEntity<Employee> updateemployee(@PathVariable int id, @RequestBody Employee employee) {
        Employee oldEmployee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFound("Employee not found with Id:" + id));

        oldEmployee.setName(employee.getName());
        oldEmployee.setEmail(employee.getEmail());
        oldEmployee.setPhone(employee.getPhone());
        oldEmployee.setExperience(employee.getExperience());
        oldEmployee.setSalary(employee.getSalary());
        oldEmployee.setDepartment(employee.getDepartment());

        employeeRepository.save(oldEmployee);
        return ResponseEntity.ok(oldEmployee);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> DeleteEmployee(@PathVariable int id){
        Employee employee=employeeRepository.findById(id).orElseThrow(()->new ResourceNotFound("Employee not found"));
        employeeRepository.delete(employee);
        return ResponseEntity.ok(HttpStatus.NO_CONTENT);
    }
}