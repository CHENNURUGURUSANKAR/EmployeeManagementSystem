package com.gutu149.SpringStarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
